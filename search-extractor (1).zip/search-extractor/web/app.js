// Proxy endpoint (works both in Docker and when the folder is moved)
const PROXY = "/api/search";

const $ = s => document.querySelector(s);
const out = $("#out");
const btn = $("#btn");
const q   = $("#q");

btn.addEventListener("click", run);
q.addEventListener("keydown", e => { if (e.key === "Enter") run(); });

async function searchGoogle(term){
  const res = await fetch(`${PROXY}?q=${encodeURIComponent(term)}`);
  if (!res.ok) {
    const t = await res.text().catch(()=>'');
    throw new Error(`API error ${res.status} — ${t}`);
  }
  const data = await res.json();
  return (data.items || []).map(it => ({
    title: it.title, link: it.link, snippet: it.snippet
  }));
}

function render(list){
  if (!list.length){ out.innerHTML = "<em>Žádné výsledky.</em>"; return; }
  out.innerHTML = list.map(r => `
    <div class="result">
      <div><a href="${r.link}" target="_blank" rel="noreferrer">${r.title}</a></div>
      <div class="muted">${r.link}</div>
      <div>${r.snippet}</div>
    </div>
  `).join("");
}

async function run(){
  const term = q.value.trim();
  if (!term){ q.focus(); return; }
  out.textContent = "Hledám…";
  try{
    const items = await searchGoogle(term);
    render(items);
  }catch(err){
    out.textContent = String(err.message || err);
  }
}
