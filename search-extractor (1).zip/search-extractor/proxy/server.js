import express from "express";
import fetch from "node-fetch";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors({ origin: true }));

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.GOOGLE_API_KEY;
const CX = process.env.GOOGLE_CX;

if (!API_KEY || !CX) {
  console.warn("WARNING: Set GOOGLE_API_KEY and GOOGLE_CX in .env");
}

app.get("/api/search", async (req, res) => {
  const q = (req.query.q || "").toString();
  if (!q) return res.status(400).json({ error: "missing q" });

  try {
    const url = new URL("https://www.googleapis.com/customsearch/v1");
    url.searchParams.set("key", API_KEY);
    url.searchParams.set("cx", CX);
    url.searchParams.set("q", q);

    const r = await fetch(url.href);
    const text = await r.text();
    res.status(r.status).type("application/json").send(text);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => console.log(`Proxy running on http://localhost:${PORT}`));
